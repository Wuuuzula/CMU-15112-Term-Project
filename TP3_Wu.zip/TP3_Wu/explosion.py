import math, random
from cmu_cs3_graphics import *

#explosion effect
def explode(app):
    for i in range(len(app.fragments)):
        cx, cy, r, angle, rotate, speed = app.fragments[i]
        app.fragments[i] = (cx+speed*math.cos(angle), cy+speed*math.sin(angle), 10, angle, rotate+20, speed + 0.1)
       
    for i in range(len(app.explosion)):
        cx, cy, r = app.explosion[i]
        app.explosion[i] = (cx, cy, r + 3)
        
    for circle in app.explosion:
        cx, cy, r = circle
        if r > 50:
            app.explosion.remove(circle)

    for fragment in app.fragments:
        cx, cy, r, angle, rotate, speed = fragment
        if (cx - r) and (cx + r) < 0:
            app.fragments.remove(fragment)
        elif (cx - r) and (cx + r) > app.width:
            app.fragments.remove(fragment)
        elif (cy - r) and (cy + r) < 0:
            app.fragments.remove(fragment)
        elif (cy - r) and (cy + r) > app.height:
            app.fragments.remove(fragment)

def addExplosion(app, cx, cy):
    direction = [i for i in range(12)]
    for i in random.sample(direction, 8):
        R, speed, rotate, r = 20, 5, 0, 10
        angle = i*30*math.pi/180
        app.fragments.append((cx+R*math.cos(angle), cy+R*math.sin(angle), r, angle, rotate, speed))
        
    for i in range(6):
        angle = i*60*math.pi/180
        r = random.randrange(2,30)
        size = random.randrange(10, 20)
        app.explosion.append((cx+r*math.cos(angle), cy+r*math.sin(angle), size))

def drawExplosion(app):
    for fragment in app.fragments:
        cx, cy, r, angle, rotate, speed = fragment
        drawStar(cx, cy, r,3, rotateAngle = rotate)
    
    for circle in app.explosion:
        cx, cy, r = circle
        drawCircle(cx, cy, r, opacity=30)