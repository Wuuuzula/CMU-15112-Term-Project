import random
from cmu_cs3_graphics import *
from widgets import *

#generate player and player class

class Player(object):
    def __init__(self,cx, cy, r, angle):
        self.cx = cx
        self.cy = cy
        self.r = r
        self.angle = angle
        self.speed = 10

    def moveUp(self,app):
        self.cy -= self.speed
        if isLegalMove(app, self.cx, self.cy-self.r/1.5) == False:
            self.cy += self.speed
    
    def moveDown(self,app):
        self.cy += self.speed
        if isLegalMove(app, self.cx, self.cy+self.r/1.5) == False:
            self.cy -= self.speed
    
    def moveLeft(self,app):
        self.cx -= self.speed
        if isLegalMove(app, self.cx-self.r/1.5, self.cy) == False:
            self.cx += self.speed

    def moveRight(self,app):
        self.cx += self.speed
        if isLegalMove(app, self.cx+self.r/1.5, self.cy) == False:
            self.cx -= self.speed

def generatePlayer(app):
    row, col = random.choice(app.cells) 
    left, top, cellWidth, cellHeight = getCellBounds(app, row, col)
    cx = left + cellWidth / 2
    cy = top + cellHeight / 2
    r = min(cellWidth, cellHeight) / 3 
    angle = random.choice([0, 90, 180, 270])
    return Player(cx, cy, r, angle)

def drawPlayer(app):
    cx, cy, r, angle = app.player.cx, app.player.cy, app.player.r, app.player.angle
    newWidth = 65-app.rows
    newHeight = newWidth * 3 / 5
    drawImage(app.playerTank,cx - 0.5*newWidth, cy - 0.5*newHeight, width = newWidth, height = newHeight, rotateAngle = 180-angle)


