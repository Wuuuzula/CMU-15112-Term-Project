import math
#some useful helper functions

# this section of code is copied from hw5 in cs_academy
def getCell(app, x, y):
    gridWidth = app.width - 2*app.margin
    gridHeight = app.height - 2*app.margin
    cellWidth = gridWidth / app.cols
    cellHeight = gridHeight / app.rows
    
    row = int((y - app.margin) / cellHeight)
    col = int((x - app.margin) / cellWidth)
    return row, col

# this section of code is copied from hw5 in cs_academy
def getCellBounds(app, row, col):
    gridWidth = app.width - 2*app.margin
    gridHeight = app.height - 2*app.margin
    cellWidth = gridWidth / app.cols
    cellHeight = gridHeight / app.rows
    left = app.margin + col*cellWidth
    top = app.margin + row*cellHeight
    
    return (left, top, cellWidth, cellHeight)

#check the legal movement
def isLegalMove(app, cx, cy):
    row, col = getCell(app, cx, cy)
    if (row, col, False) in app.walls:
        return False

    return True

def isCollision(cx1, cy1, r1, cx2, cy2, r2):
    if distance(cx1, cy1, cx2, cy2) < (r1 + r2)*0.5:
        return True

def distance(x1, y1, x2, y2):
    return math.sqrt((x1-x2)**2 + (y1-y2)**2)