import pygame
import math, random, json
from cmu_cs3_graphics import *
from explosion import *
from widgets import *

#create bullets and some bullet methods

def bulletsFly(app):
    speed = 12
    for i in range(len(app.bullets)):
        cx, cy, r, angle = app.bullets[i]
        row, col = getCell(app, cx, cy)
        if isLegalMove(app, cx+r, cy) == False and isLegalMove(app, cx, cy-r) == False:
            app.bullets[i] = (cx-0.5*r, cy+0.5*r, r, 180+angle)
        elif isLegalMove(app, cx+r, cy) == False and isLegalMove(app, cx, cy+r) == False:
            app.bullets[i] = (cx-0.5*r, cy-0.5*r, r, 180+angle)
        elif isLegalMove(app, cx-r, cy) == False and isLegalMove(app, cx, cy+r) == False:
            app.bullets[i] = (cx+0.5*r, cy-0.5*r, r, 180+angle)
        elif isLegalMove(app, cx-r, cy) == False and isLegalMove(app, cx, cy-r) == False:
            app.bullets[i] = (cx+0.5*r, cy+0.5*r, r, 180+angle)

        elif isLegalMove(app, cx, cy-r) == False:
            app.bullets[i] = (cx, cy+0.5*r, r, -angle)
        elif isLegalMove(app, cx, cy+r) == False:
            app.bullets[i] = (cx, cy-0.5*r, r, -angle)
        elif isLegalMove(app, cx-r, cy) == False:
            app.bullets[i] = (cx+0.5*r, cy, r, 180-angle)
        elif isLegalMove(app, cx+r, cy) == False:
            app.bullets[i] = (cx-0.5*r, cy, r, 180-angle)
        
        cx, cy, r, angle = app.bullets[i]      
        app.bullets[i] = (cx+speed*math.cos(angle*math.pi/180), cy-speed*math.sin(angle*math.pi/180), r, angle)

#check the collision of bullets
def bulletCollision(app):
    for bullet in app.bullets:
        cx, cy, r, angle = bullet
        for enemy in app.enemies:
            if isCollision(cx, cy, r, enemy.cx, enemy.cy, enemy.r):
                pygame.mixer.music.load(app.crashEffect)
                pygame.mixer.Channel(0).play(pygame.mixer.Sound(app.crashEffect))
                app.enemies.remove(enemy)
                if bullet in app.bullets:
                    app.bullets.remove(bullet)
                addExplosion(app, cx, cy)
                app.scores += 1
        
        if isCollision(cx, cy, r, app.player.cx, app.player.cy, app.player.r):
            pygame.mixer.music.load(app.crashEffect)
            pygame.mixer.Channel(0).play(pygame.mixer.Sound(app.crashEffect))
            addExplosion(app, cx, cy)
            app.gameOver = True
            updateRanking(app)
            app.bullets.remove(bullet)

def updateRanking(app):
    info = open("local_scores.json")
    json_dict = json.load(info)
    newRanking = {k:v for k, v in sorted(json_dict.items(), key = lambda item: item[1], reverse=True )}
    #this method is learnt from https://stackoverflow.com/questions/613183/how-do-i-sort-a-dictionary-by-value
    top5Ranking = {}
    i = 1
    for player in newRanking:
        top5Ranking[player] = newRanking[player]
        i += 1
        if i > 5:
            break
        
    app.ranking = top5Ranking
    info.close()


def drawBullets(app):
    for (cx, cy, r, angle) in app.bullets:
        drawCircle(cx, cy, r, rotateAngle = angle, fill="black")