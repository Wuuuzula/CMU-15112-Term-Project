from cmu_cs3_graphics import *
from cmu_graphics.utils import *
from PIL import Image
import pygame
import json
import random
import math

from player import *
from mazes import *
from explosion import *
from enemy import *
from bullet import *
from drawFunctions import *
from widgets import *

#Use WASD to control the movements, and press mouse to choose maps and shoot bullets

def onAppStart(app):
    app.Dmaze = False
    app.Pmaze = False
    #choose which map
    app.scores = 0
    app.gameStart = False
    app.flashing = 50
    app.flashingSpeed = 2
    app.enemyMove = 1
    #control enemy move frequency
    app.growingCircle = None
    app.transition = False
    #whether need transition animation

    #load images
    app.playerTank = Image.open("images/greenTank.png")
    app.playerTank = CMUImage(app.playerTank)
    app.zombie = Image.open("images/zombie.png") #Credit it to https://zombieclub.io/
    app.zombie = CMUImage(app.zombie)
    app.logo = Image.open("images/logo.png")
    app.logo = CMUImage(app.logo)
    app.map1Unselected = Image.open("images/map1Unselected.png")
    app.map1Unselected = CMUImage(app.map1Unselected)
    app.map1selected = Image.open("images/map1selected.png")
    app.map1selected = CMUImage(app.map1selected)
    app.map2Unselected = Image.open("images/map2Unselected.png")
    app.map2Unselected = CMUImage(app.map2Unselected)
    app.map2selected = Image.open("images/map2selected.png")
    app.map2selected = CMUImage(app.map2selected)
    app.instruction = Image.open("images/instruction.png")
    app.instruction = CMUImage(app.instruction)
    app.closing = Image.open("images/closing.png")
    app.closing = CMUImage(app.closing)

    app.map1Select = False
    app.map2Select = False
    app.pause = False
    app.ranking = {}
    app.showRanking = False

    #load music Credit to: https://www.pygame.org/docs/ref/music.html
    pygame.mixer.init()
    app.crashEffect = "music/crash.mp3"
    app.shootEffect = "music/shoot.mp3"
    #two sound tracks credit to https://mixkit.co/free-sound-effects/explosion/
    app.bgm = "music/background.mp3"
    #background music is from https://downloads.khinsider.com/game-soundtracks/album/counter-strike-global-offensive-soundtrack/01%2520Counter-Strike%2520-%2520Global%2520Offensive%2520Theme%25201.mp3
    pygame.mixer.music.load(app.bgm)
    pygame.mixer.music.set_volume(0.2)
    reset(app)

#setup
def reset(app):
    #map size
    app.rows = random.randrange(5,15,2)
    app.cols = app.rows + 4
    app.margin = 10
    app.walls = []
    app.cells = []
    app.player = Player(app.width/2,app.height/2,0,0) #initially set the player outside of the windo
    app.enemies = []
    app.bullets = []
    app.gameOver = False
    app.tick = 1
    app.freeze = 1
    app.fragments = []
    app.explosion = []
    updateRanking(app)
    if app.gameStart == False:
        pygame.mixer.music.load(app.bgm)
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play()

def onStep(app):
    if app.gameStart == True:
        pygame.mixer.music.stop()
    app.tick += 1
    #flashing animation
    if app.gameStart == False or app.gameOver == True:
        if app.flashing < 50:
            app.flashingSpeed = 2
        elif app.flashing == 100:
            app.flashingSpeed = -2
        app.flashing += app.flashingSpeed
    #control bullets
    if app.tick % 300 == 0:
        if app.bullets != []:
            app.bullets.pop(0)
    if app.gameOver != True and app.pause == False:
        doStep(app)
    if app.enemies == []:
        app.freeze += 1
    if app.freeze % 50 == 0 and app.gameOver == False:
        mapRefresh(app)

    #transition animation in starting page
    if app.transition == True:
        cx, cy, r = app.growingCircle
        app.growingCircle = (cx, cy, r+10)
        if (cx - r) < 0 and (cx + r) > app.width:
            app.transition = False
            
    #Only in "real game" mode enemies will move
    if app.Pmaze == True and app.transition == False:
        app.enemyMove += 1
        if app.enemyMove % 25 == 0:
            for enemy in app.enemies:
                enemy.path = []
                cx, cy = enemy.cx, enemy.cy
                enemyRow, enemyCol = getCell(app, cx, cy)
                enemy.path = findPathHelper(app, (enemyRow,enemyCol), [], [])

    #select maps
    if app.gameStart == False:
        if (150 <= app.player.cx <= 550) and (300 <= app.player.cy <= 700):
            app.map1Select = True
        else:
            app.map1Select = False
        if (650 <= app.player.cx <= 1050) and (300 <= app.player.cy <= 700):
            app.map2Select = True
        else:
            app.map2Select = False

def doStep(app):
    #check for bullet rebound
    bulletsFly(app)
    #check the collisions
    bulletCollision(app)
    #enemies are running around
    enemiesRunning(app)
    #check explosion
    explode(app)

#restart game or continue gaming
def mapRefresh(app):
    #check which map currently in
    if app.Dmaze == True:
        reset(app)
        generateDWall(app)
        generateDCell(app)
        createDMaze(app)
        app.player = generatePlayer(app)
        generateEnemy(app)
    elif app.Pmaze == True:
        reset(app)
        generatePWall(app)
        generatePCell(app)
        createPMaze(app)
        app.player = generatePlayer(app)
        generateEnemy(app)

#edit the local JSON file
def addUserInfo(app):
    with open("local_scores.json") as json_file:
        json_decoded = json.load(json_file)
    userName = app.getTextInput("What's your user ID? (press N to skip)")
    if userName == "n" or userName == "N":
        return
    json_decoded[userName] = app.scores
    with open("local_scores.json", 'w') as json_file:
        json.dump(json_decoded, json_file)

#mouse could control the rotation of the player, as well as the shooting angle
def onMouseMove(app, mouseX, mouseY):
    diffY = -(mouseY-app.player.cy)
    diffX = mouseX-app.player.cx+0.001
    newAngle = (math.atan(diffY/diffX))*180/math.pi
    if diffY > 0 and diffX > 0:
        app.player.angle = newAngle
    elif diffY > 0 and diffX < 0:
        app.player.angle = newAngle + 180
    elif diffY < 0 and diffX < 0:
        app.player.angle = newAngle + 180
    elif diffY < 0 and diffX > 0:
        app.player.angle = newAngle + 360

#choose maps and shoot bullets
def onMousePress(app, mouseX, mouseY):
    if app.gameStart == False:
        if app.map1Select == True:
            app.transition = True
            app.growingCircle = (mouseX, mouseY, 10)
            reset(app)
            generateDWall(app)
            generateDCell(app)
            createDMaze(app)
            app.player = generatePlayer(app)
            generateEnemy(app)
            app.Dmaze = True
            app.Pmaze = False
            app.gameStart = True
        elif app.map2Select == True:
            app.transition = True
            app.growingCircle = (mouseX, mouseY, 20)
            reset(app)
            generatePWall(app)
            generatePCell(app)
            createPMaze(app)
            app.player = generatePlayer(app)
            generateEnemy(app)
            app.Dmaze = False
            app.Pmaze = True
            app.gameStart = True
    if app.walls == []:
        return
    if app.gameOver == True:
        return
    bulletX = app.player.cx+(app.player.r+app.player.r/3)*math.cos(app.player.angle*math.pi/180)
    bulletY = app.player.cy-(app.player.r+app.player.r/3)*math.sin(app.player.angle*math.pi/180)
    #shoot the bullets
    if isLegalMove(app, bulletX, bulletY):
        if (len(app.bullets) < 6) and haveToRebound(app):
            pygame.mixer.music.load(app.shootEffect)
            pygame.mixer.Channel(0).play(pygame.mixer.Sound(app.shootEffect))
            app.bullets.append((bulletX, bulletY, app.player.r/3, app.player.angle))

#limit the shooting angle
def haveToRebound(app):
    if 10 <= app.player.angle <= 80:
        return True
    elif 100 <= app.player.angle <= 170:
        return True
    elif 190 <= app.player.angle <= 260:
        return True
    elif 280 <= app.player.angle <= 350:
        return True
    return False

def onKeyPress(app, key):
    #pause the game
    if key == "p" or key == "P":
        app.pause = not app.pause
    #show ranking
    if app.gameStart == False:
        if key == "r":
            app.showRanking = not app.showRanking

    #gameover choice
    if app.gameOver == True:
        if app.map2Select == True:
            if key == "h" or key == "H":
                addUserInfo(app)
        if key == "1":
            reset(app)
            generateDWall(app)
            generateDCell(app)
            createDMaze(app)
            app.player = generatePlayer(app)
            generateEnemy(app)
            app.Dmaze = True
            app.Pmaze = False
            app.gameStart = True
            app.scores = 0
            app.map2Select = False
        
        if key == "2":
            reset(app)
            generatePWall(app)
            generatePCell(app)
            createPMaze(app)
            app.player = generatePlayer(app)
            generateEnemy(app)
            app.Dmaze = False
            app.Pmaze = True
            app.gameStart = True
            app.scores = 0
            app.map1Select = False

    #press escape to back to the menu
    if key == "escape":
        app.Dmaze = False
        app.Pmaze = False
        app.scores = 0
        app.gameStart = False
        app.map1Select = False
        app.map2Select = False
        reset(app)

#move the player
def onKeyHold(app, keys):
    if app.pause == False:
        if "w" in keys:
            app.player.moveUp(app)
        if "a" in keys:
            app.player.moveLeft(app)
        if "s" in keys:
            app.player.moveDown(app)
        if "d" in keys:
            app.player.moveRight(app)

def redrawAll(app):
    if app.gameStart == False:
        drawStartPage(app)
        drawRanking(app)
    if app.transition == True:
        drawTransition(app)
    elif app.gameStart != False:
        drawWalls(app)
        drawBullets(app)
        drawEnemies(app)
        drawExplosion(app)
    if app.gameOver == True:
        drawGameOver(app)
    elif app.gameOver == False:
        drawPlayer(app)

runApp(width = 1200, height = 800)