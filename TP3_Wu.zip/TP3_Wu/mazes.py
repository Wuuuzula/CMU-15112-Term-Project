import random
from widgets import *

#two maze generation algorithms

##############################Revised Recursive Division Algorithm#################################################
def generateDWall(app):
    for col in range(app.cols):
        if (0, col) not in app.walls:
            app.walls.append((0, col, False))
        if (app.rows-1, col) not in app.walls:
            app.walls.append((app.rows-1, col, False))
    for row in range(app.rows):
        if (row, 0) not in app.walls:
            app.walls.append((row, 0, False))
        if (row, app.cols-1) not in app.walls:
            app.walls.append((row, app.cols-1, False))

def generateDCell(app):
    for row in range(1, app.rows, 2):
        for col in range(1, app.cols, 2):
            app.cells.append((row,col))

def createDMaze(app):
    row = random.choice([i for i in range(2, app.rows-1, 2)])
    return createDMazeHelper(app, (row, app.cols-1, False), app.cols-2, "left")  

#the algorithm is learned from https://weblog.jamisbuck.org/2011/1/12/maze-generation-recursive-division-algorithm#:~:text=The%20%E2%80%9Crecursive%20division%E2%80%9D%20algorithm%20is,Begin%20with%20an%20empty%20field.
def createDMazeHelper(app, cell, length, orientation):
    if length <= 1:
        return
    else:
        #add lines
        newWalls = addDWalls(app, cell, length, orientation)
        if newWalls == None:
            return 
        app.walls += newWalls

        if orientation == "left" or orientation == "right":
            result = selectNextWall(app, orientation, newWalls)
            if result == None:
                return
            newCell1, newCell2 = result
            row1, col1, isWall = newCell1
            row2, col2, isWall = newCell2
            #for upward length
            lengthUp = 0
            for i in range(1, app.rows):
                if (row1 - i, col1, False) in app.walls:
                    break
                lengthUp += 1
            
        #     #for downward length
            lengthDown = 0
            for i in range(1, app.rows):
                if (row2 + i, col2, False) in app.walls:
                    break
                lengthDown += 1
            return [createDMazeHelper(app, newCell1, lengthUp, "up"), createDMazeHelper(app, newCell2, lengthDown, "down")]

        elif orientation == "up" or orientation == "down":
            result = selectNextWall(app, orientation, newWalls)
            if result == None:
                return
            newCell1, newCell2 = result
            row1, col1, isWall = newCell1
            row2, col2, isWall = newCell2
        #     #for left length
            lengthLeft = 0
            for i in range(1, app.cols):
                if (row1, col1 - i, False) in app.walls:
                    break
                lengthLeft += 1
            #for right length
                
            lengthRight = 0
            for i in range(1, app.cols):
                if (row2, col2 + i, False) in app.walls:
                    break
                lengthRight += 1
            return [createDMazeHelper(app, newCell1, lengthLeft, "left"), createDMazeHelper(app, newCell2, lengthRight, "right")]

        #pick up a new cell from the wall
        #if orientation horizontal --> change to vertical, up or down
        #get length for each direction, use for loop to see when hits the bound
        #got cell, length, orientation, call the function again

def selectNextWall(app, orientation, wallLst):
    result = []
    if orientation == "left" or orientation == "right":
        while len(result) < 2:
            if wallLst == []:
                return None
            cell = random.choice(wallLst)
            if (cell[0]+1, cell[1]) in app.cells or (cell[0]-1, cell[1]) in app.cells:
                wallLst.remove(cell)
                continue
            else:
                if cell not in result:
                    result.append(cell)
                    wallLst.remove(cell)

    if orientation == "up" or orientation == "down":
        while len(result) < 2:
            if wallLst == []:
                return None
            cell = random.choice(wallLst)
            if (cell[0], cell[1]+1) in app.cells or (cell[0], cell[1]-1) in app.cells:
                wallLst.remove(cell)
                continue
            else:
                if cell not in result: 
                    result.append(cell)
                    wallLst.remove(cell)

    return (result[0], result[1])

def addDWalls(app, cell, length, orientation):
    row, col, isWall = cell
    walls = []
    if orientation == 'up':
        passage = selectPassage(app, cell, length, orientation)
        if passage == None:
            return
        for i in range(1, length+1):
            if row - i != passage[0]:
                walls.append((row-i, col, False))
    if orientation == 'down':
        passage = selectPassage(app, cell, length, orientation)
        if passage == None:
            return
        for i in range(1, length+1):
            if row + i != passage[0]:
                walls.append((row+i, col, False))
    if orientation == 'right':
        passage = selectPassage(app, cell, length, orientation)
        if passage == None:
            return
        for i in range(1, length+1):
            if col + i != passage[1]:
                walls.append((row, col+i, False))
    if orientation == 'left':
        passage = selectPassage(app, cell, length, orientation)
        if passage == None:
            return
        for i in range(1, length+1):
            if col - i != passage[1]:
                walls.append((row, col-i, False))

    return walls

def selectPassage(app, cell, length, orientation):
    row, col, isWall = cell
    if orientation == 'up':
        passages = []
        for i in range(1, length+1):
            newRow = row - i
            if (newRow, col-1) in app.cells or (newRow, col+1) in app.cells:
                passages.append((newRow, col))
    if orientation == 'down':
        passages = []
        for i in range(1, length+1):
            newRow = row + i
            if (newRow, col-1) in app.cells or (newRow, col+1) in app.cells:
                passages.append((newRow, col))

    if orientation == 'right':
        passages = []
        for i in range(1, length+1):
            newCol = col + i
            if (row-1, newCol) in app.cells or (row+1, newCol) in app.cells:
                passages.append((row, newCol))

    if orientation == 'left':
        passages = []
        for i in range(1, length+1):
            newCol = col - i
            if (row-1, newCol) in app.cells or (row+1, newCol) in app.cells:
                passages.append((row, newCol))
    
    if passages == []:
        return

    return random.choice(passages)

################################################################################

##############################Prim's Algorithm#################################################
def generatePWall(app):
    for row in range(app.rows):
        for col in range(app.cols):
            app.walls.append((row,col,False))

def generatePCell(app):
    for row in range(1, app.rows, 2):
        for col in range(1, app.cols, 2):
            app.cells.append((row,col))

#create Prim's maze
def createPMaze(app):
    visitedCell = []
    i = random.randint(0, len(app.cells)-1) #pick up a cell
    visitedCell.append(app.cells[i])
    wallList = addWalls(app, app.cells[i])
    createPMazeHelper(app, visitedCell, wallList)

def addWalls(app, cell):
    wallLst = []
    up, down, right, left = (-1,0), (1,0), (0,1), (0,-1)
    directions = [up, down, right, left]
    for drow, dcol in directions:
        newRow = cell[0] + drow
        newCol = cell[1] + dcol
        if (newRow, newCol, False) in app.walls:
            wallLst.append((newRow, newCol, False))
    return wallLst

#the algorithm is learned from https://en.wikipedia.org/wiki/Maze_generation_algorithm
def createPMazeHelper(app, visitedCell, wallList):
    if wallList == []:
        for (row, col) in visitedCell:
            idx = app.walls.index((row, col, False))
            app.walls[idx] = (row, col, True)
    else:
        pickWall = random.choice(wallList)
        wallIdx = app.walls.index(pickWall)
        unvisitedCell = onlyOneVisited(app, pickWall, visitedCell)
        if unvisitedCell != None:
            app.walls[wallIdx] = (pickWall[0], pickWall[1], True)
            visitedCell.append(unvisitedCell)
            wallList += addWalls(app, unvisitedCell)
        wallList.remove(pickWall)
        return createPMazeHelper(app, visitedCell, wallList)

def onlyOneVisited(app, pickWall, visitedCell):
    up, down, right, left = (-1,0), (1,0), (0,1), (0,-1)
    directions = [up, down, right, left]
    row, col, isWall = pickWall
    nOfCell = 0
    unvisitedCell = []
    for drow, dcol in directions:
        newRow = row + drow
        newCol = col + dcol
        if (newRow, newCol) in visitedCell:
            nOfCell += 1
        elif (newRow, newCol) in app.cells:
            unvisitedCell.append((newRow, newCol))
    if nOfCell == 1 and len(unvisitedCell) == 1:
        return unvisitedCell[0]
    return None
################################################################################
