from cmu_cs3_graphics import *
from bullet import *
from widgets import *
import random

#enemy-related functions and classes

class Enemy(object):
    def __init__(self, cx, cy, r, direction):
        self.cx = cx
        self.cy = cy
        self.r = r
        self.direction = direction
        self.speed = 4
        self.path = []

    def wander(self,app):
        #enemies movements
        if self.path != []:
            targetRow, targetCol = self.path[0]
            left, top, cellWidth, cellHeight = getCellBounds(app, targetRow, targetCol)
            targetCx = left + cellWidth/2
            targetCy = top + cellHeight/2
            if self.cx < targetCx:
                self.cx += self.speed
            elif self.cx > targetCx:
                self.cx -= self.speed
            if self.cy > targetCy:
                self.cy -= self.speed
            elif self.cy < targetCy:
                self.cy += self.speed

def generateEnemy(app):
    NofEnemies = (app.rows-5)//2 + 1
    playerCx, playerCy, playerR, playerAngle = app.player.cx, app.player.cy, app.player.r, app.player.angle
    playerRow, playerCol = getCell(app, playerCx, playerCy)
    while len(app.enemies) < NofEnemies:
        row = random.randrange(0, app.rows)
        col = random.randrange(0, app.cols)
        if (row, col, False) not in app.walls and (row, col) != (playerRow, playerCol):
            left, top, cellWidth, cellHeight = getCellBounds(app, row, col)
            cx = left + cellWidth / 2
            cy = top + cellHeight / 2
            r = min(cellWidth, cellHeight) / 3
            direction = random.choice(["down", "right"])
            app.enemies.append(Enemy(cx, cy, r, direction))

def enemiesRunning(app):
    for enemy in app.enemies:
        playerX, playerY, playerR, playerAngle = app.player.cx, app.player.cy, app.player.r, app.player.angle
        #check whether the player has hit the enemies
        if isCollision(enemy.cx, enemy.cy, enemy.r, playerX, playerY, playerR) == True:
            pygame.mixer.music.load(app.crashEffect)
            pygame.mixer.Channel(0).play(pygame.mixer.Sound(app.crashEffect))
            addExplosion(app, enemy.cx, enemy.cy)
            app.gameOver = True
            updateRanking(app)
            app.score = 0
        enemy.wander(app)

#credit to the depthfirst search on https://en.wikipedia.org/wiki/Maze_generation_algorithm
def findPathHelper(app, currentCell, visitedCell, pathLst):
    cx, cy = app.player.cx, app.player.cy
    playerRow, playerCol = getCell(app, cx, cy)
    up, down, right, left = (-1,0), (1,0), (0,1), (0,-1)
    directions = [up, down, right, left]
    random.shuffle(directions)
    if currentCell == (playerRow, playerCol):
        return pathLst
    else:
        for drow, dcol in directions:
            row, col = currentCell
            newRow, newCol = row + drow, col + dcol
            if (0 <= newRow < app.rows) and (0 <= newCol < app.cols) and (newRow, newCol, False) not in app.walls and (newRow, newCol) not in visitedCell:
                pathLst.append((newRow, newCol))
                nextCell = (newRow, newCol)
                visitedCell.append(nextCell)
                result = findPathHelper(app, nextCell, visitedCell, pathLst)
                if result != None:
                    return result
                visitedCell.remove(nextCell)
                pathLst.remove((newRow, newCol))
                nextCell = (row,col)

        return None

def drawEnemies(app):
    if app.enemies != []:
        for enemy in app.enemies:
            newWidth = 50 - app.rows
            newHeight = newWidth * 5/4
            drawImage(app.zombie,enemy.cx - 0.5*newWidth, enemy.cy - 0.5*newHeight, width=newWidth, height=newHeight)
