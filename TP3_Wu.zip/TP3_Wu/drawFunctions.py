from cmu_cs3_graphics import *
from widgets import *

def drawWalls(app):
    for cell in app.walls:
        (row, col, isWall) = cell
        (left, top, cellWidth, cellHeight) = getCellBounds(app, row, col)
        color = "black" if isWall is False else "white"
        drawRect(left, top, cellWidth, cellHeight, fill = color)

def drawRanking(app):
    if app.showRanking == True:
        drawRect(300, 100, 600, 600, fill = "black", opacity = 50)
        drawLabel("Local Ranking", 600, 150, fill ="white", size = 40, bold=True)
        i = 1
        for user in app.ranking:
            drawLabel(f"{i}. Player ID: {user}                         {app.ranking[user]} kills", 600, 150 + i*100, fill ="white", size = 30, bold=True)
            i += 1

def drawTransition(app):
    if app.growingCircle != None:
        drawRect(0, 0 ,app.width, app.height, fill ="black")
        cx, cy, r = app.growingCircle
        drawCircle(cx, cy, r, fill="white")

def drawGameOver(app):
    drawRect(0,0,app.width,app.height, fill="white", opacity=50)
    drawLabel("Game Over", app.width/2, app.height/2, size = 50, bold = True)
    drawImage(app.closing, 100, app.height/2+100, opacity = app.flashing)
    drawLabel(f"You have killed {app.scores} zombies", app.width/2, app.height/2 - 150, size = 40, bold=True)
    if app.map2Select == True:
        drawLabel(f"(Press H to Record your score!)", app.width/2, app.height/2 - 100, size = 40, bold=True)

def drawStartPage(app):
    # width = 900, height = 100
    drawImage(app.logo, 200, 10, width = 800, height = 300, opacity = app.flashing)
    drawLabel("Press R to view the Rank", 1000, 50, size = 30, bold = True, opacity = app.flashing)
    drawImage(app.instruction, 150, 630, width = 900)
    if app.map1Select == True:
        drawImage(app.map1selected, 150, 250, width = 400, height = 400)
    else:
        drawImage(app.map1Unselected, 150, 250, width = 400, height = 400)
    if app.map2Select == True:
        drawImage(app.map2selected, 650, 250, width = 400, height = 400)
    else:
        drawImage(app.map2Unselected, 650, 250, width = 400, height = 400)